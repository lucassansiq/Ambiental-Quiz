/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import model.Jogador;

/**
 *
 * @author Lucas Hype
 */
public class Principal {
    public static void main(String[] args) {
        Jogador jogador = new Jogador("Lucas");
        System.out.println(jogador);
        
        
    }

}
